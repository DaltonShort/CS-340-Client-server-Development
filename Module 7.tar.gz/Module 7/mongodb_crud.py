from pymongo import MongoClient

class CRUD(object):
    """ CRUD operations for MongoDB """

    def __init__(self, user, password, host, port, db, col):
        """
        Initializes the MongoClient and connects to the specified MongoDB database and collection.
        """
        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[col]

    def create(self, data):
        """
        Inserts a document into the specified MongoDB collection.

        Args:
            data (dict): A dictionary containing key/value pairs for the document.

        Returns:
            bool: True if the insert is successful, False otherwise.
        """
        if data:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("False")

    def read(self, query):
        """
        Queries for documents in the specified MongoDB collection based on the provided key/value pair.

        Args:
            query (dict): A dictionary containing key/value pairs for the query.

        Returns:
            list: A list of documents matching the query, or an empty list if no documents are found.
        """
        cursor = self.collection.find(query)
        result = [document for document in cursor]
        return result

    def update(self, query, update_data):
        """
        Queries for and updates document(s) in the specified MongoDB collection.

        Args:
            query (dict): A dictionary containing key/value pairs for the query.
            update_data (dict): A dictionary containing key/value pairs for the update.

        Returns:
            int: The number of objects modified in the collection.
        """
        result = self.collection.update_many(query, {'$set': update_data})
        return result.modified_count

    def delete(self, query):
        """
        Queries for and removes document(s) from the specified MongoDB collection.

        Args:
            query (dict): A dictionary containing key/value pairs for the query.

        Returns:
            int: The number of objects removed from the collection.
        """
        result = self.collection.delete_many(query)
        return result.deleted_count
